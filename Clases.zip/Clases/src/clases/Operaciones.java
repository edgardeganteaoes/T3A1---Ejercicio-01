package clases;

public class Operaciones {
    private int a;
    private int b;
    private double resultado;

    public Operaciones(int a, int b, double resultado) {
        this.a = a;
        this.b = b;
        this.resultado = resultado;
    }

    @Override
    public String toString() {
        return "Operaciones{" + "a=" + a + ", b=" + b + ", resultado=" + resultado + '}';
    }

    public Operaciones() {
    }

    public int getA() {
        return a;
    }

    public void setA(int a) {
        this.a = a;
    }

    public int getB() {
        return b;
    }

    public void setB(int b) {
        this.b = b;
    }

    public double getResultado() {
        return resultado;
    }

    public void setResultado(double resultado) {
        this.resultado = resultado;
    }
}
