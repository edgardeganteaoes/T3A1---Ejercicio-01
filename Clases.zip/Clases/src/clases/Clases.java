/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clases;

import java.util.Scanner;

/**
 *
 * @author edgar
 */
public class Clases {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        suma();
    }
    
    public static void suma() {
        Scanner scanner = new Scanner(System.in);
        Operaciones operaciones = new Operaciones();
        
        System.out.println("Ingresa el primer número: ");
        int a = scanner.nextInt();
        operaciones.setA(a);
        
        System.out.println("Ingresa el segundo número: ");
        int b = scanner.nextInt();
        operaciones.setB(b);
        
        operaciones.setResultado(operaciones.getA()+operaciones.getB());
        System.out.println("Resultado: " + operaciones.getResultado());
    }
}
